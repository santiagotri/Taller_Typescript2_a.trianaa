export class Student {
    atributo: string;
    valor: string;
  
    constructor(atributo: string, valor: string) {
      this.atributo = atributo;
      this.valor = valor;
    }
  }