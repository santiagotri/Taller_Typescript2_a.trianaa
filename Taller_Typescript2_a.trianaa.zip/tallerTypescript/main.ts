import { Course } from './course.js';

import { dataCourses } from './dataCourses.js';

import { Student } from './student.js';

import { dataStudents } from './dataStudents.js';

let coursesTbody: HTMLElement = document.getElementById('courses')!;
let studentsTbody: HTMLElement = document.getElementById('students')!;
const btnfilterByName: HTMLElement = document.getElementById("button-filterByName")!;
const btnfilterByCreditos: HTMLElement = document.getElementById("button-filterByCreditos")!;
const inputSearchBoxCreditosInicial: HTMLInputElement = <HTMLInputElement> document.getElementById("search-box-creditosInicial")!;
const inputSearchBoxCreditosFinal: HTMLInputElement = <HTMLInputElement> document.getElementById("search-box-creditosFinal")!;
const inputSearchBox: HTMLInputElement = <HTMLInputElement> document.getElementById("search-box")!;
const totalCreditElm: HTMLElement = document.getElementById("total-credits")!;


btnfilterByName.onclick = () => applyFilterByName();
btnfilterByCreditos.onclick = () => applyFilterByCreditos();

renderCoursesInTable(dataCourses);
renderStudentsInTable(dataStudents);

totalCreditElm.innerHTML = `${getTotalCredits(dataCourses)}`


function renderCoursesInTable(courses: Course[]): void {
  console.log('Desplegando cursos');
  courses.forEach((course) => {
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${course.name}</td>
                           <td>${course.professor}</td>
                           <td>${course.credits}</td>`;
    coursesTbody.appendChild(trElement);
  });
}

function renderStudentsInTable(students: Student[]): void {
  console.log('Desplegando informacion del estudiante');
  students.forEach((student) => {
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${student.atributo}</td>
                           <td>${student.valor}</td>`;
    studentsTbody.appendChild(trElement);
  });
}
 

 

function applyFilterByName() { 
  let text = inputSearchBox.value;
  text = (text == null) ? '' : text;
  clearCoursesInTable();
  let coursesFiltered: Course[] = searchCourseByName(text, dataCourses);
  renderCoursesInTable(coursesFiltered);
}

function searchCourseByName(nameKey: string, courses: Course[]) {
  return nameKey === '' ? dataCourses : courses.filter( c => 
    c.name.match(nameKey));
}

function applyFilterByCreditos() { 
  let inicial = inputSearchBoxCreditosInicial.value;
  let final = inputSearchBoxCreditosFinal.value;
  inicial = (inicial == null) ? '0' : inicial;
  final = (final == null) ? '1000' : final;
  clearCoursesInTable();
  let coursesFiltered: Course[] = searchCourseByCreditos(+inicial,+final, dataCourses);
  renderCoursesInTable(coursesFiltered);
}

function searchCourseByCreditos(inicial: number, final:number, courses: Course[]) {
  return inicial === 0 ? dataCourses : courses.filter( c => 
    c.credits<=final && c.credits>=inicial);
}

function getTotalCredits(courses: Course[]): number {
  let totalCredits: number = 0;
  courses.forEach((course) => totalCredits = totalCredits + course.credits);
  return totalCredits;
}

function clearCoursesInTable() {
  while (coursesTbody.hasChildNodes()) {
    if (coursesTbody.firstChild != null) {
      coursesTbody.removeChild(coursesTbody.firstChild);
     
    }
  }
}
