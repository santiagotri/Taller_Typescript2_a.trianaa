import { Student } from './student.js';
export var dataStudents = [
    new Student("Código", "201923265"),
    new Student("Cédula", "1001168176"),
    new Student("Edad", "19 Años"),
    new Student("Dirección", "Cra. 1 #18a-12"),
    new Student("Teléfono", "3153516112")
];
