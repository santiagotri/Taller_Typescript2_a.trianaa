var Student = /** @class */ (function () {
    function Student(atributo, valor) {
        this.atributo = atributo;
        this.valor = valor;
    }
    return Student;
}());
export { Student };
